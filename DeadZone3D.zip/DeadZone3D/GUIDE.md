# Dead Zone 3D : guide complet pour débutant

Jeu de tir 3D contre des zombies, 100 % original (aucune image ni son emprunté : les modèles sont des formes 3D générées par le code, les sons sont synthétisés).

**Ce que contient le jeu**
- 10 missions sur 4 décors (jour, crépuscule, nuit, zone toxique) : éliminer des zombies, survivre, affronter un boss (2 boss).
- 3 types de zombies + le boss « Colosse » ; tirs à la tête = dégâts ×2,2.
- 5 armes (pistolet, mitraillette, fusil d'assaut, fusil à pompe, fusil de précision avec lunette), chargeur et munitions de réserve, rechargement, caisses de munitions et de soins.
- Progression : pièces, rang et expérience, 3 étoiles par mission, boutique d'armes, 3 améliorations (dégâts, santé, munitions). Sauvegarde automatique.
- Commandes tactiles : joystick à gauche, glisser à droite pour viser, boutons Tir / Recharger / Changer d'arme / Viser / Pause.
- AdMob : bannière dans les menus, vidéo récompensée pour doubler les gains d'une mission, continuer après une mort, ou gagner +250 pièces.

---

## Étape 0. Comprendre ce que vous avez

| Mot | Sens simple |
|---|---|
| **Projet Android Studio** | Le dossier `DeadZone3D` : le code source de l'app. |
| **APK** | Fichier installable directement sur un téléphone (pour tester). |
| **AAB** | Fichier que Google Play exige pour publier une nouvelle app. |
| **Debug / Release** | Debug = version de test. Release = version à publier, signée avec votre clé. |

Le jeu lui-même est dans `app/src/main/assets/www/` (HTML + JavaScript + WebGL). Android Studio l'enveloppe dans une vraie application Android.

---

## Étape 1. Tester le jeu tout de suite (sans rien installer)

Sur un ordinateur : ouvrez `app/src/main/assets/www/index.html` dans Chrome. Commandes : **Z Q S D** pour bouger, clic dans le jeu puis souris pour viser, **clic gauche** pour tirer, **clic droit** pour viser, **R** recharger, **X** changer d'arme, **Échap** pause. Les vidéos publicitaires sont simulées dans ce mode.

---

## Étape 2. Obtenir l'APK : trois chemins

### Chemin A : avec un ordinateur (recommandé, le plus fiable)

1. Installez **Android Studio** (gratuit) : https://developer.android.com/studio
2. Décompressez `DeadZone3D.zip`.
3. Android Studio > **Open** > choisissez le dossier `DeadZone3D`.
4. Attendez la fin de « Gradle sync » (barre en bas ; il télécharge tout seul ce qu'il faut). Acceptez les licences / téléchargements proposés.
5. Menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Cliquez sur « locate » : votre fichier est `app/build/outputs/apk/debug/app-debug.apk`.
7. Envoyez-le sur votre téléphone (câble USB, WhatsApp, Drive), ouvrez-le et autorisez l'installation depuis cette source.

Pour tester directement : activez sur le téléphone **Options pour les développeurs > Débogage USB**, branchez-le et appuyez sur le bouton ▶ d'Android Studio.

### Chemin B : sans ordinateur (depuis un téléphone), via GitHub

1. Créez un compte gratuit sur github.com et un dépôt **privé**.
2. Envoyez-y tout le contenu du dossier (y compris le dossier caché `.github`). Depuis le navigateur du téléphone, utilisez « Add file > Upload files ».
3. Onglet **Actions** > « Compiler l'APK » > **Run workflow**.
4. Après quelques minutes, ouvrez l'exécution terminée et téléchargez l'**artefact « DeadZone-apk »** (un zip contenant l'APK).

> Ce script de compilation en ligne n'a pas pu être testé ici. S'il échoue, copiez-moi le message d'erreur et je le corrige.

### Chemin C : je vous guide pas à pas par chat
Si un message d'erreur apparaît à n'importe quelle étape, envoyez-moi une capture d'écran.

---

## Étape 3. Créer vos identifiants AdMob

Vous avez déjà ajouté l'application « Dead Zone » dans AdMob. Il reste à créer **deux blocs d'annonces** :

1. AdMob > Applications > Dead Zone > **Blocs d'annonces** > Ajouter > **Bannière**, nom `banniere_menu`.
2. Ajouter > **Récompensée**, nom `video_recompense` (récompense : 1 « pièce » : la valeur est ignorée, le jeu gère sa propre récompense).
3. Notez : l'**ID de l'application** (avec `~`), l'**ID de la bannière** et l'**ID de la récompensée** (avec `/`).
4. Ouvrez `app/src/main/res/values/ads.xml` et remplacez les 3 identifiants de **test** par les vôtres.

> ⚠️ **Règle d'or** : pendant vos essais, gardez les identifiants de TEST. Ne cliquez jamais sur vos propres vraies publicités : Google peut suspendre votre compte AdMob pour « trafic invalide ». Remplacez par les vrais ID uniquement pour la version publiée.

> Les publicités ne s'affichent qu'avec une connexion Internet ; une nouvelle app AdMob peut mettre quelques heures à quelques jours avant de diffuser de vraies pubs.

---

## Étape 4. Personnaliser avant publication

- **Identifiant d'application** : dans `app/build.gradle.kts`, changez `applicationId = "com.deadzone.game"` par quelque chose d'unique à vous, par exemple `com.votrenom.deadzone`. Il ne pourra plus changer après publication. Faites de même pour `namespace` et le dossier `java/com/deadzone/game`, ou laissez `namespace` tel quel (c'est permis).
- **Nom affiché** : `app/src/main/res/values/strings.xml`.
- **Équilibrage** (prix, dégâts, missions) : `app/src/main/assets/www/js/data.js`.

---

## Étape 5. Publier sur Google Play

1. Créez un **compte développeur Google Play** (frais uniques d'environ 25 $). Les nouveaux comptes personnels doivent passer par une phase de test fermé obligatoire avant la production ; vérifiez les règles actuelles dans la Play Console.
2. **Fabriquer le fichier AAB signé** (Android Studio) : **Build > Generate Signed App Bundle / APK > Android App Bundle**. Créez une **clé de signature** (« Create new… »), et **sauvegardez le fichier de clé et ses mots de passe à plusieurs endroits** : si vous les perdez, vous ne pourrez plus mettre à jour l'app. Choisissez la variante **release**. Le fichier est `app/release/app-release.aab`.
3. Avant de compiler la version finale : vos vrais identifiants AdMob (étape 3) et `versionCode`/`versionName` (`app/build.gradle.kts`).
4. Play Console > **Créer une application** > remplissez :
   - **Fiche** : nom, description, `store/icone-512.png` (icône), `store/banniere-1024x500.png` (image de présentation), captures d'écran `store/jeu-*.png`.
   - **Politique de confidentialité** : hébergez `store/privacy.html` (après avoir remplacé vos nom et e-mail) sur un site (GitHub Pages, par exemple) et collez le lien.
   - **Contenu de l'application** : *Annonces* = oui ; *Public cible* = 13+ ou plus (pas d'enfants : le jeu contient de la violence de fiction) ; *Classification du contenu* = questionnaire (violence fantastique) ; *Sécurité des données* : déclarez que l'app partage l'identifiant publicitaire / l'appareil avec AdMob pour la publicité.
5. **Production > Créer une version** > envoyez le `.aab` > envoyez à examen (de quelques heures à plusieurs jours).
6. Dans AdMob, **liez l'application à sa fiche Google Play** (le message « Ajoutez des plates-formes de téléchargement » vu à l'écran) : c'est nécessaire pour que les publicités soient pleinement diffusées.

**Exigences à connaître**
- Depuis le 31 août 2026, les nouvelles apps doivent cibler Android 16 (API 36) : c'est déjà configuré.
- **Consentement RGPD** : pour les joueurs de l'Espace économique européen et du Royaume-Uni, Google exige un message de consentement publicitaire (SDK « UMP »). Il n'est **pas encore intégré** à ce projet ; configurez le message dans AdMob > Confidentialité et messagerie, puis demandez-moi de l'intégrer au code avant de diffuser dans ces pays. Si vous ne ciblez que d'autres pays, vous pouvez décocher l'EEE dans la distribution.
- Le SDK publicitaire utilisé (`play-services-ads` 25.5.0) est annoncé par Google comme en « mode maintenance » : il fonctionne, mais Google recommande à terme de migrer vers « GMA Next-Gen ». Aucune urgence pour une première version.

---

## Étape 6. Dépannage rapide

| Problème | Solution |
|---|---|
| Écran noir au lancement | Votre téléphone n'a pas WebGL (très rare) : mettez à jour « Android System WebView » dans le Play Store. |
| Pas de pub | Vérifiez Internet ; les identifiants de test fonctionnent toujours ; une vraie app neuve peut mettre un moment. |
| Le jeu rame | Réglages > Qualité graphique > Basse. |
| « Gradle sync failed » | Copiez le message et envoyez-le moi. |
| App refusée par Google Play | Lisez l'e-mail de rejet : le plus souvent c'est la politique de confidentialité ou la déclaration des publicités. |

---

## Structure du projet

```
DeadZone3D/
├─ app/src/main/
│  ├─ java/com/deadzone/game/MainActivity.java   ← lance le jeu + AdMob + sauvegarde
│  ├─ AndroidManifest.xml
│  ├─ res/values/ads.xml                         ← VOS identifiants AdMob
│  └─ assets/www/                                ← LE JEU
│     ├─ index.html   (menus et interface)
│     └─ js/ data.js (armes, missions) · engine.js (3D) · game.js (jeu) · ui.js · audio.js
├─ store/   ← icône, bannière, captures, politique de confidentialité
└─ .github/workflows/build-apk.yml               ← compilation en ligne
```
