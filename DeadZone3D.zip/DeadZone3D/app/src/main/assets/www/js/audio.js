'use strict';
/* =====================================================================
   AUDIO.JS  -  Sons générés par le code (aucun fichier audio = aucun
   problème de droits d'auteur). Bruitages de tirs, zombies, interface.
   ===================================================================== */
const Snd = {
  ctx: null, on: true, last: {},
  init(){
    if (this.ctx) return;
    try {
      const A = window.AudioContext || window.webkitAudioContext;
      this.ctx = new A();
      const n = this.ctx.sampleRate, buf = this.ctx.createBuffer(1, n, n), d = buf.getChannelData(0);
      for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
      this.nb = buf;
      this.master = this.ctx.createGain();
      this.master.gain.value = .55;
      this.master.connect(this.ctx.destination);
    } catch (e) { this.ctx = null; }
  },
  resume(){ if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume(); },
  gate(k, ms){
    const t = performance.now();
    if (t - (this.last[k] || 0) < ms) return false;
    this.last[k] = t; return true;
  },
  tone(f, d, type, v, f2){
    if (!this.on || !this.ctx) return;
    const c = this.ctx, t = c.currentTime, o = c.createOscillator(), g = c.createGain();
    o.type = type || 'square';
    o.frequency.setValueAtTime(f, t);
    if (f2) o.frequency.exponentialRampToValueAtTime(f2, t + d);
    g.gain.setValueAtTime(v || .2, t);
    g.gain.exponentialRampToValueAtTime(.001, t + d);
    o.connect(g); g.connect(this.master);
    o.start(t); o.stop(t + d + .02);
  },
  noise(d, v, freq, ftype){
    if (!this.on || !this.ctx) return;
    const c = this.ctx, t = c.currentTime, s = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
    s.buffer = this.nb; f.type = ftype || 'lowpass'; f.frequency.value = freq || 2000;
    g.gain.setValueAtTime(v || .3, t);
    g.gain.exponentialRampToValueAtTime(.001, t + d);
    s.connect(f); f.connect(g); g.connect(this.master);
    s.start(t, Math.random() * .5, d + .05);
  },
  shoot(id){
    if (id === 'pistol')       { this.noise(.12, .5, 2600); this.tone(190, .10, 'square', .18, 60); }
    else if (id === 'smg')     { this.noise(.08, .35, 3200); this.tone(170, .07, 'square', .14, 70); }
    else if (id === 'rifle')   { this.noise(.14, .5, 1900); this.tone(125, .12, 'sawtooth', .2, 50); }
    else if (id === 'shotgun') { this.noise(.32, .85, 950); this.tone(95, .26, 'sawtooth', .3, 38); }
    else                       { this.noise(.5, .85, 1300); this.tone(75, .42, 'sawtooth', .35, 30); }
  },
  hit(){ if (this.gate('hit', 40)) this.noise(.04, .3, 1500, 'bandpass'); },
  zdie(){ if (this.gate('zdie', 60)) this.tone(150, .4, 'sawtooth', .18, 40); },
  groan(){ if (this.gate('groan', 900)) this.tone(80 + Math.random() * 50, .7, 'sawtooth', .07, 55); },
  hurt(){ if (this.gate('hurt', 150)) { this.tone(210, .22, 'square', .22, 90); this.noise(.12, .3, 900); } },
  pickup(){ this.tone(660, .08, 'sine', .2); setTimeout(() => this.tone(990, .1, 'sine', .2), 70); },
  click(){ this.tone(520, .04, 'square', .08); },
  reload(){ this.tone(300, .05, 'square', .1); setTimeout(() => this.tone(520, .06, 'square', .1), 450); },
  empty(){ if (this.gate('empty', 200)) this.tone(900, .03, 'square', .1); },
  win(){ [523, 659, 784, 1047].forEach((f, i) => setTimeout(() => this.tone(f, .2, 'triangle', .22), i * 120)); },
  lose(){ [330, 262, 196, 130].forEach((f, i) => setTimeout(() => this.tone(f, .3, 'sawtooth', .18), i * 160)); }
};
