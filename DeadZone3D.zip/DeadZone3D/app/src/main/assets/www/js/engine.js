'use strict';
/* =====================================================================
   ENGINE.JS  -  Petit moteur 3D maison (WebGL). Tout est fabriqué avec
   des cubes colorés : style "low-poly", léger pour les téléphones.
   ===================================================================== */

// Convertit '#rrggbb' en [r,g,b] entre 0 et 1
function C(hex){
  const n = parseInt(hex.slice(1), 16);
  return [(n >> 16 & 255) / 255, (n >> 8 & 255) / 255, (n & 255) / 255];
}

// ---- Matrices 4x4 (colonnes, comme WebGL) -----------------------------
const Mat = {
  id(){ return new Float32Array([1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1]); },
  mul(a, b){
    const o = new Float32Array(16);
    for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) {
      let s = 0;
      for (let k = 0; k < 4; k++) s += a[k * 4 + r] * b[c * 4 + k];
      o[c * 4 + r] = s;
    }
    return o;
  },
  T(x, y, z){ const m = Mat.id(); m[12] = x; m[13] = y; m[14] = z; return m; },
  S(x, y, z){ const m = Mat.id(); m[0] = x; m[5] = y; m[10] = z; return m; },
  RX(a){ const c = Math.cos(a), s = Math.sin(a); return new Float32Array([1,0,0,0, 0,c,s,0, 0,-s,c,0, 0,0,0,1]); },
  RY(a){ const c = Math.cos(a), s = Math.sin(a); return new Float32Array([c,0,-s,0, 0,1,0,0, s,0,c,0, 0,0,0,1]); },
  persp(fov, asp, n, f){
    const t = 1 / Math.tan(fov / 2), nf = 1 / (n - f);
    return new Float32Array([t / asp,0,0,0, 0,t,0,0, 0,0,(f + n) * nf,-1, 0,0,2 * f * n * nf,0]);
  },
  lookAt(e, c){
    let fx = c[0] - e[0], fy = c[1] - e[1], fz = c[2] - e[2];
    let l = Math.hypot(fx, fy, fz) || 1; fx /= l; fy /= l; fz /= l;
    let sx = -fz, sy = 0, sz = fx; l = Math.hypot(sx, sz) || 1; sx /= l; sz /= l;
    const ux = sy * fz - sz * fy, uy = sz * fx - sx * fz, uz = sx * fy - sy * fx;
    return new Float32Array([
      sx, ux, -fx, 0,
      sy, uy, -fy, 0,
      sz, uz, -fz, 0,
      -(sx * e[0] + sy * e[1] + sz * e[2]), -(ux * e[0] + uy * e[1] + uz * e[2]), fx * e[0] + fy * e[1] + fz * e[2], 1
    ]);
  }
};

// ---- Géométrie : un cube = 6 faces ------------------------------------
const FACES = [
  { n:[0,0,1],  v:[[-1,-1,1],[1,-1,1],[1,1,1],[-1,1,1]] },
  { n:[0,0,-1], v:[[1,-1,-1],[-1,-1,-1],[-1,1,-1],[1,1,-1]] },
  { n:[1,0,0],  v:[[1,-1,1],[1,-1,-1],[1,1,-1],[1,1,1]] },
  { n:[-1,0,0], v:[[-1,-1,-1],[-1,-1,1],[-1,1,1],[-1,1,-1]] },
  { n:[0,1,0],  v:[[-1,1,1],[1,1,1],[1,1,-1],[-1,1,-1]] },
  { n:[0,-1,0], v:[[-1,-1,-1],[1,-1,-1],[1,-1,1],[-1,-1,1]] }
];
const QUAD_IDX = [0, 1, 2, 0, 2, 3];

// Un "Batch" assemble plein d'objets fixes (sol, murs, arbres...) en UN seul
// gros bloc : c'est beaucoup plus rapide à dessiner.
class Batch {
  constructor(){ this.d = []; }
  _v(x, y, z, nx, ny, nz, c){ this.d.push(x, y, z, nx, ny, nz, c[0], c[1], c[2]); }
  box(cx, cy, cz, sx, sy, sz, col, ry){
    ry = ry || 0;
    const co = Math.cos(ry), si = Math.sin(ry);
    for (const f of FACES) {
      const n = f.n, nx = n[0] * co + n[2] * si, nz = -n[0] * si + n[2] * co;
      for (const i of QUAD_IDX) {
        const v = f.v[i], x = v[0] * sx / 2, y = v[1] * sy / 2, z = v[2] * sz / 2;
        this._v(cx + x * co + z * si, cy + y, cz - x * si + z * co, nx, n[1], nz, col);
      }
    }
  }
  quad(x, z, size, y, col){           // carreau horizontal (sol)
    const a = [x, y, z + size], b = [x + size, y, z + size], c = [x + size, y, z], d = [x, y, z];
    const P = [a, b, c, a, c, d];
    for (const p of P) this._v(p[0], p[1], p[2], 0, 1, 0, col);
  }
  pyramid(cx, cy, cz, base, h, col){  // cime d'arbre, touffe d'herbe
    const b = base / 2, apex = [cx, cy + h, cz];
    const c = [[cx - b, cy, cz - b], [cx + b, cy, cz - b], [cx + b, cy, cz + b], [cx - b, cy, cz + b]];
    for (let i = 0; i < 4; i++) {
      const p = c[i], q = c[(i + 1) % 4];
      const e1 = [q[0] - p[0], q[1] - p[1], q[2] - p[2]], e2 = [apex[0] - p[0], apex[1] - p[1], apex[2] - p[2]];
      let n = [e1[1] * e2[2] - e1[2] * e2[1], e1[2] * e2[0] - e1[0] * e2[2], e1[0] * e2[1] - e1[1] * e2[0]];
      const l = Math.hypot(n[0], n[1], n[2]) || 1; n = [n[0] / l, n[1] / l, n[2] / l];
      const mx = (p[0] + q[0]) / 2 - cx, mz = (p[2] + q[2]) / 2 - cz;
      if (n[0] * mx + n[2] * mz < 0) n = [-n[0], -n[1], -n[2]];
      this._v(p[0], p[1], p[2], n[0], n[1], n[2], col);
      this._v(q[0], q[1], q[2], n[0], n[1], n[2], col);
      this._v(apex[0], apex[1], apex[2], n[0], n[1], n[2], col);
    }
  }
  upload(gl){
    const buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(this.d), gl.STATIC_DRAW);
    return { buf: buf, count: this.d.length / 9 };
  }
}

// ---- Shaders -----------------------------------------------------------
const VS = [
  'attribute vec3 aPos; attribute vec3 aNor; attribute vec3 aCol;',
  'uniform mat4 uVP; uniform mat4 uModel; uniform vec3 uTint; uniform vec3 uEmis;',
  'uniform vec3 uLightDir; uniform vec3 uSun; uniform vec3 uAmb; uniform vec3 uCam; uniform vec2 uFog;',
  'varying vec3 vCol; varying float vFog;',
  'void main(){',
  '  vec4 w = uModel * vec4(aPos, 1.0);',
  '  vec3 n = normalize((uModel * vec4(aNor, 0.0)).xyz);',
  '  float d = max(dot(n, uLightDir), 0.0);',
  '  float hemi = 0.5 + 0.5 * n.y;',
  '  vec3 light = uAmb * (0.65 + 0.35 * hemi) + uSun * d;',
  '  vCol = aCol * uTint * light + uEmis;',
  '  vFog = clamp((distance(w.xyz, uCam) - uFog.x) / (uFog.y - uFog.x), 0.0, 1.0);',
  '  gl_Position = uVP * w;',
  '}'
].join('\n');
const FS = [
  'precision mediump float;',
  'varying vec3 vCol; varying float vFog; uniform vec3 uFogCol;',
  'void main(){ gl_FragColor = vec4(mix(vCol, uFogCol, vFog), 1.0); }'
].join('\n');

// ---- Rendu -------------------------------------------------------------
const R = {
  gl: null, u: {}, cur: null, cube: null, th: null,
  init(canvas){
    const gl = canvas.getContext('webgl', { antialias: false, alpha: false, depth: true, powerPreference: 'high-performance' }) ||
               canvas.getContext('experimental-webgl');
    if (!gl) return false;
    this.gl = gl;
    const sh = (type, src) => {
      const o = gl.createShader(type); gl.shaderSource(o, src); gl.compileShader(o);
      if (!gl.getShaderParameter(o, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(o));
      return o;
    };
    const p = gl.createProgram();
    gl.attachShader(p, sh(gl.VERTEX_SHADER, VS));
    gl.attachShader(p, sh(gl.FRAGMENT_SHADER, FS));
    gl.linkProgram(p);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p));
    gl.useProgram(p);
    for (const n of ['uVP','uModel','uTint','uEmis','uLightDir','uSun','uAmb','uCam','uFog','uFogCol'])
      this.u[n] = gl.getUniformLocation(p, n);
    this.loc = [gl.getAttribLocation(p, 'aPos'), gl.getAttribLocation(p, 'aNor'), gl.getAttribLocation(p, 'aCol')];
    for (const l of this.loc) gl.enableVertexAttribArray(l);
    gl.enable(gl.DEPTH_TEST);
    const b = new Batch(); b.box(0, 0, 0, 1, 1, 1, [1, 1, 1]);
    this.cube = b.upload(gl);
    return true;
  },
  setTheme(th){
    this.th = { fog: C(th.fog), sun: th.sun, amb: th.amb };
  },
  bind(m){
    if (this.cur === m) return;
    const gl = this.gl;
    gl.bindBuffer(gl.ARRAY_BUFFER, m.buf);
    gl.vertexAttribPointer(this.loc[0], 3, gl.FLOAT, false, 36, 0);
    gl.vertexAttribPointer(this.loc[1], 3, gl.FLOAT, false, 36, 12);
    gl.vertexAttribPointer(this.loc[2], 3, gl.FLOAT, false, 36, 24);
    this.cur = m;
  },
  begin(vp, cam, w, h){
    const gl = this.gl, u = this.u, th = this.th;
    gl.viewport(0, 0, w, h);
    gl.clearColor(th.fog[0], th.fog[1], th.fog[2], 1);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.uniformMatrix4fv(u.uVP, false, vp);
    gl.uniform3f(u.uCam, cam[0], cam[1], cam[2]);
    gl.uniform3f(u.uLightDir, .45, .8, .35);
    gl.uniform3fv(u.uSun, th.sun);
    gl.uniform3fv(u.uAmb, th.amb);
    gl.uniform3fv(u.uFogCol, th.fog);
    gl.uniform2f(u.uFog, 18, 95);
    this.cur = null;
  },
  beginGun(proj){                       // l'arme est dessinée par-dessus le monde
    const gl = this.gl, u = this.u;
    gl.clear(gl.DEPTH_BUFFER_BIT);
    gl.uniformMatrix4fv(u.uVP, false, proj);
    gl.uniform3f(u.uCam, 0, 0, 0);
    gl.uniform2f(u.uFog, 1e4, 2e4);
  },
  drawStatic(m){
    const gl = this.gl, u = this.u;
    this.bind(m);
    gl.uniformMatrix4fv(u.uModel, false, Mat.id());
    gl.uniform3f(u.uTint, 1, 1, 1);
    gl.uniform3f(u.uEmis, 0, 0, 0);
    gl.drawArrays(gl.TRIANGLES, 0, m.count);
  },
  box(model, tint, emis){
    const gl = this.gl, u = this.u;
    this.bind(this.cube);
    gl.uniformMatrix4fv(u.uModel, false, model);
    gl.uniform3f(u.uTint, tint[0], tint[1], tint[2]);
    gl.uniform3f(u.uEmis, emis[0], emis[1], emis[2]);
    gl.drawArrays(gl.TRIANGLES, 0, 36);
  }
};
