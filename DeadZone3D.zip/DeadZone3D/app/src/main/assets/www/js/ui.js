'use strict';
/* =====================================================================
   UI.JS  -  Sauvegarde, publicités (pont vers Android) et menus.
   ===================================================================== */
const $ = id => document.getElementById(id);

// ---- SAUVEGARDE --------------------------------------------------------
// Sur Android : enregistrée dans l'application (SharedPreferences).
// Sur ordinateur (test) : enregistrée dans le navigateur (localStorage).
const Save = {
  data: null,
  defaults(){
    return { v: 1, coins: 200, xp: 0, owned: ['pistol'], upg: { dmg: 0, hp: 0, ammo: 0 },
             stars: [], set: { sens: 1, q: 1, snd: 1 } };
  },
  load(){
    let raw = '';
    try { raw = (window.Android && Android.load) ? String(Android.load()) : (localStorage.getItem('dz_save') || ''); } catch (e) {}
    const d = this.defaults();
    try {
      const j = JSON.parse(raw);
      if (j && typeof j === 'object') {
        Object.assign(d, j);
        d.upg = Object.assign({ dmg: 0, hp: 0, ammo: 0 }, j.upg || {});
        d.set = Object.assign({ sens: 1, q: 1, snd: 1 }, j.set || {});
        if (!Array.isArray(d.owned)) d.owned = ['pistol'];
        if (d.owned.indexOf('pistol') < 0) d.owned.unshift('pistol');
        if (!Array.isArray(d.stars)) d.stars = [];
      }
    } catch (e) {}
    this.data = d;
  },
  write(){
    const s = JSON.stringify(this.data);
    try { if (window.Android && Android.save) Android.save(s); else localStorage.setItem('dz_save', s); } catch (e) {}
  },
  unlocked(i){ return i === 0 || (this.data.stars[i - 1] || 0) > 0; },
  nextMission(){
    for (let i = 0; i < MISSIONS.length; i++) if (!(this.data.stars[i] > 0)) return i;
    return MISSIONS.length - 1;
  }
};

// ---- PUBLICITÉS (AdMob, côté Android) ----------------------------------
const Ads = {
  pending: null,
  banner(show){
    try { if (window.Android && Android.setBanner) Android.setBanner(!!show); } catch (e) {}
  },
  // Lance une vidéo récompensée. cb() est appelé SEULEMENT si le joueur a tout regardé.
  rewarded(cb){
    if (window.Android && Android.showRewarded) { this.pending = cb; Android.showRewarded(); }
    else { UI.toast('[Test navigateur] Pub vidéo simulée'); cb(); }   // sur PC : on simule
  }
};
// Appelée par Android à la fin de la vidéo
window.onRewardResult = function (ok, reason) {
  const cb = Ads.pending; Ads.pending = null;
  if (!cb) return;
  if (ok) cb();
  else UI.toast(reason === 'closed' ? 'Vidéo interrompue : pas de récompense' : 'Aucune vidéo disponible, réessayez dans un instant');
};

// ---- MENUS -------------------------------------------------------------
const UI = {
  cur: 'sc-menu',
  screens: ['sc-menu', 'sc-missions', 'sc-armory', 'sc-settings', 'sc-pause', 'sc-result'],
  toastT: null,
  show(id){
    for (const s of this.screens) $(s).classList.toggle('hidden', s !== id);
    $('hud').classList.toggle('hidden', id !== 'hud');
    this.cur = id;
    Ads.banner(id !== 'hud');            // bannière visible dans les menus, cachée en pleine action
    if (id === 'sc-menu') this.menu();
    else if (id === 'sc-missions') this.missions();
    else if (id === 'sc-armory') this.armory();
    else if (id === 'sc-settings') this.settings();
  },
  toast(msg){
    const t = $('toast');
    t.textContent = msg; t.classList.add('on');
    clearTimeout(this.toastT);
    this.toastT = setTimeout(() => t.classList.remove('on'), 2600);
  },
  menu(){
    const r = rankOf(Save.data.xp);
    $('rankText').textContent = 'Rang ' + r.lv;
    $('xpFill').style.width = Math.round(100 * r.cur / r.need) + '%';
    $('menuCoins').textContent = Save.data.coins;
    const n = Save.nextMission();
    $('mPlay').textContent = (Save.data.stars[0] > 0 ? 'CONTINUER · Mission ' : 'JOUER · Mission ') + (n + 1);
  },
  missions(){
    let h = '';
    MISSIONS.forEach((m, i) => {
      const un = Save.unlocked(i), st = Save.data.stars[i] || 0;
      h += '<button class="mcard' + (un ? '' : ' lock') + '" data-i="' + i + '"><b>' + (i + 1) + '</b>' +
           '<span class="mn">' + (un ? m.name : 'Verrouillée') + '</span>' +
           '<span class="md">' + (un ? missionDesc(m) : 'Terminez la mission précédente') + '</span>' +
           '<span class="stars">' + '★'.repeat(st) + '☆'.repeat(3 - st) + '</span></button>';
    });
    $('missionGrid').innerHTML = h;
  },
  armory(){
    const d = Save.data;
    $('armCoins').textContent = d.coins;
    let h = '';
    for (const w of WEAPONS) {
      const own = d.owned.indexOf(w.id) >= 0;
      h += '<div class="card"><h3>' + w.name + '</h3>' +
           '<div class="stat">Dégâts <b>' + (w.pellets > 1 ? w.dmg + ' ×' + w.pellets : w.dmg) + '</b></div>' +
           '<div class="stat">Cadence <b>' + (1 / w.rate).toFixed(1) + ' /s</b></div>' +
           '<div class="stat">Chargeur <b>' + w.mag + '</b></div>' +
           (own ? '<button class="btn small" disabled>Possédée ✔</button>'
                : '<button class="btn small gold" data-buy="' + w.id + '">Acheter 🪙 ' + w.price + '</button>') + '</div>';
    }
    $('armWeapons').innerHTML = h;
    h = '';
    for (const k in UPG) {
      const u = UPG[k], lv = d.upg[k] || 0;
      h += '<div class="card"><h3>' + u.name + ' <small>niv. ' + lv + '/' + u.max + '</small></h3>' +
           '<div class="stat">' + u.desc + '</div>' +
           (lv >= u.max ? '<button class="btn small" disabled>Maximum ✔</button>'
                        : '<button class="btn small gold" data-up="' + k + '">Améliorer 🪙 ' + u.cost(lv) + '</button>') + '</div>';
    }
    $('armUpg').innerHTML = h;
  },
  buy(id){
    const w = WEAPONS.find(x => x.id === id), d = Save.data;
    if (!w || d.owned.indexOf(id) >= 0) return;
    if (d.coins < w.price) { this.toast('Pas assez de pièces'); return; }
    d.coins -= w.price; d.owned.push(id); Save.write(); Snd.pickup(); this.armory();
  },
  upgrade(k){
    const u = UPG[k], d = Save.data, lv = d.upg[k] || 0;
    if (!u || lv >= u.max) return;
    const c = u.cost(lv);
    if (d.coins < c) { this.toast('Pas assez de pièces'); return; }
    d.coins -= c; d.upg[k] = lv + 1; Save.write(); Snd.pickup(); this.armory();
  },
  settings(){
    const s = Save.data.set;
    $('setSens').value = s.sens; $('setSensVal').textContent = Number(s.sens).toFixed(1);
    $('setQ').value = String(s.q); $('setSnd').checked = !!s.snd;
  },
  showResult(r){
    $('resTitle').textContent = 'MISSION RÉUSSIE !';
    $('resBody').innerHTML =
      '<div class="bigstars">' + '★'.repeat(r.stars) + '☆'.repeat(3 - r.stars) + '</div>' +
      '<div class="line">Zombies éliminés <b>' + r.kills + '</b></div>' +
      '<div class="line">Tirs à la tête <b>' + r.head + '</b></div>' +
      '<div class="line">Temps <b>' + Math.floor(r.time / 60) + ':' + ('0' + Math.floor(r.time % 60)).slice(-2) + '</b></div>' +
      '<div class="line gold">Pièces gagnées <b>🪙 ' + r.coins * (r.doubled ? 2 : 1) + '</b></div>' +
      '<div class="line">Expérience <b>+' + r.xp + ' XP</b></div>';
    let b = '';
    if (!r.doubled) b += '<button class="btn gold" id="rDouble">🎬 Doubler les pièces (+' + r.coins + ')</button>';
    if (r.idx < MISSIONS.length - 1) b += '<button class="btn" id="rNext">Mission suivante</button>';
    b += '<button class="btn alt" id="rRetry">Rejouer</button><button class="btn alt" id="rMenu">Menu</button>';
    $('resBtns').innerHTML = b;
    if ($('rDouble')) $('rDouble').onclick = () => Game.doubleReward();
    if ($('rNext')) $('rNext').onclick = () => Game.next();
    $('rRetry').onclick = () => Game.retry();
    $('rMenu').onclick = () => Game.toMenu();
    this.show('sc-result');
  },
  showDeath(canRevive){
    $('resTitle').textContent = 'VOUS ÊTES MORT';
    $('resBody').innerHTML = '<div class="line">Les zombies ont eu raison de vous…</div>';
    let b = '';
    if (canRevive) b += '<button class="btn gold" id="rRevive">🎬 Continuer (regarder une vidéo)</button>';
    b += '<button class="btn" id="rRetry">Réessayer</button><button class="btn alt" id="rMenu">Menu</button>';
    $('resBtns').innerHTML = b;
    if ($('rRevive')) $('rRevive').onclick = () => Game.reviveWithAd();
    $('rRetry').onclick = () => Game.retry();
    $('rMenu').onclick = () => Game.toMenu();
    this.show('sc-result');
  },
  init(){
    const click = f => (...a) => { Snd.init(); Snd.resume(); Snd.click(); f(...a); };
    $('mPlay').onclick = click(() => Game.start(Save.nextMission()));
    $('mMissions').onclick = click(() => this.show('sc-missions'));
    $('mArmory').onclick = click(() => this.show('sc-armory'));
    $('mSettings').onclick = click(() => this.show('sc-settings'));
    $('missBack').onclick = click(() => this.show('sc-menu'));
    $('armBack').onclick = click(() => this.show('sc-menu'));
    $('setBack').onclick = click(() => this.show('sc-menu'));
    $('pResume').onclick = click(() => Game.resume());
    $('pRestart').onclick = click(() => Game.retry());
    $('pQuit').onclick = click(() => Game.toMenu());
    $('missionGrid').onclick = e => {
      const b = e.target.closest ? e.target.closest('[data-i]') : null;
      if (!b) return;
      const i = +b.getAttribute('data-i');
      if (!Save.unlocked(i)) { this.toast('Terminez la mission précédente'); return; }
      Snd.init(); Snd.resume(); Snd.click(); Game.start(i);
    };
    const armoryClick = e => {
      const t = e.target.closest ? e.target.closest('button') : null;
      if (!t) return;
      if (t.getAttribute('data-buy')) this.buy(t.getAttribute('data-buy'));
      else if (t.getAttribute('data-up')) this.upgrade(t.getAttribute('data-up'));
    };
    $('armWeapons').onclick = armoryClick;
    $('armUpg').onclick = armoryClick;
    $('adCoins').onclick = click(() => Ads.rewarded(() => {
      Save.data.coins += 250; Save.write(); this.armory(); Snd.pickup(); this.toast('+250 pièces !');
    }));
    $('setSens').oninput = e => {
      Save.data.set.sens = +e.target.value; $('setSensVal').textContent = Number(e.target.value).toFixed(1); Save.write();
    };
    $('setQ').onchange = e => { Save.data.set.q = +e.target.value; Save.write(); Game.resize(); };
    $('setSnd').onchange = e => { Save.data.set.snd = e.target.checked ? 1 : 0; Snd.on = !!Save.data.set.snd; Save.write(); };
    let rt = null;
    $('setReset').onclick = () => {
      if (rt) { clearTimeout(rt); rt = null; Save.data = Save.defaults(); Save.write(); this.settings(); $('setReset').textContent = 'Réinitialiser la progression'; this.toast('Progression effacée'); }
      else { $('setReset').textContent = 'Appuyez encore pour confirmer'; rt = setTimeout(() => { rt = null; $('setReset').textContent = 'Réinitialiser la progression'; }, 3000); }
    };
  }
};

// ---- Liens avec Android -------------------------------------------------
// Bouton "retour" d'Android
window.onNativeBack = function () {
  if (UI.cur === 'hud') { Game.pause(); return 'handled'; }
  if (UI.cur === 'sc-pause') { Game.resume(); return 'handled'; }
  if (UI.cur === 'sc-result') { Game.toMenu(); return 'handled'; }
  if (UI.cur !== 'sc-menu') { UI.show('sc-menu'); return 'handled'; }
  return 'exit';
};
// L'application passe en arrière-plan : on met le jeu en pause
window.onNativePause = function () { Game.autoPause(); };
