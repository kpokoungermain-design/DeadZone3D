'use strict';
/* =====================================================================
   DATA.JS  -  Toutes les données du jeu (armes, zombies, missions...)
   C'est ICI que vous modifiez l'équilibrage : prix, dégâts, missions.
   ===================================================================== */

// ---- ARMES -----------------------------------------------------------
// dmg = dégâts par balle, rate = secondes entre 2 tirs, mag = taille du chargeur,
// reserve = munitions de réserve au début d'une mission, reload = temps de rechargement
// body = pièces 3D du modèle de l'arme : [x,y,z, largeur,hauteur,longueur, couleur]
const WEAPONS = [
  { id:'pistol', name:'Pistolet', price:0, dmg:24, rate:.26, mag:12, reserve:72, reload:1.0,
    spread:.010, pellets:1, zoom:1.4, kick:.06,
    body:[[0,.02,-.12,.045,.05,.22,'#2b2f36'],[0,-.06,-.02,.04,.10,.05,'#1d2025'],[0,.01,-.25,.03,.03,.04,'#0f1114']], mz:-.28 },
  { id:'smg', name:'Mitraillette', price:700, dmg:14, rate:.075, mag:30, reserve:150, reload:1.4,
    spread:.028, pellets:1, zoom:1.4, kick:.035,
    body:[[0,0,-.14,.06,.08,.34,'#30343b'],[0,-.11,-.10,.04,.15,.05,'#1d2025'],[0,-.01,.10,.04,.06,.12,'#242830'],[0,.012,-.38,.03,.03,.14,'#15171b']], mz:-.46 },
  { id:'rifle', name:"Fusil d'assaut", price:1600, dmg:27, rate:.105, mag:30, reserve:180, reload:1.7,
    spread:.018, pellets:1, zoom:1.8, kick:.04,
    body:[[0,0,-.18,.06,.09,.50,'#3a3f46'],[0,-.005,-.44,.066,.07,.20,'#5a4632'],[0,-.01,.14,.05,.10,.20,'#5a4632'],[0,-.11,-.16,.045,.15,.06,'#1d2025'],[0,.065,-.20,.02,.03,.04,'#111111']], mz:-.56 },
  { id:'shotgun', name:'Fusil à pompe', price:2400, dmg:13, rate:.85, mag:6, reserve:36, reload:2.3,
    spread:.075, pellets:8, zoom:1.2, kick:.10,
    body:[[0,0,-.20,.06,.07,.50,'#4a3b2a'],[0,.03,-.40,.035,.035,.60,'#202226'],[0,-.03,-.36,.06,.05,.16,'#2a2a2a'],[0,-.01,.12,.05,.09,.20,'#4a3b2a']], mz:-.72 },
  { id:'sniper', name:'Fusil de précision', price:3600, dmg:150, rate:1.15, mag:5, reserve:30, reload:2.4,
    spread:.0015, pellets:1, zoom:4, kick:.12, scope:true,
    body:[[0,0,-.20,.05,.07,.60,'#2c3a2c'],[0,.005,-.66,.025,.025,.50,'#15171b'],[0,.07,-.20,.04,.04,.22,'#111111'],[0,-.01,.16,.05,.10,.22,'#2c3a2c']], mz:-.92 }
];

// ---- ZOMBIES ---------------------------------------------------------
const ZTYPES = {
  walker: { name:'Zombie',  hp:60,   speed:1.9, dmg:9,  scale:1.00, reach:1.35, skin:'#7fa05a', pants:'#3b4252' },
  runner: { name:'Coureur', hp:38,   speed:3.8, dmg:7,  scale:0.95, reach:1.25, skin:'#a3bf6e', pants:'#2e3440', shirt:'#7a3a3a' },
  brute:  { name:'Brute',   hp:230,  speed:1.3, dmg:20, scale:1.35, reach:1.7,  skin:'#6b8a50', pants:'#2b2f3a', shirt:'#4a3030' },
  boss:   { name:'Le Colosse', hp:2600, speed:1.7, dmg:32, scale:2.05, reach:2.4, skin:'#8c5a4a', pants:'#241c1c', shirt:'#3a1f1f' }
};

// ---- DÉCORS (thèmes visuels) -----------------------------------------
const THEMES = [
  { name:'Jour brumeux', ground:['#6d7b52','#657349'], fog:'#b8c4b0', sun:[1.0,.95,.85], amb:[.55,.58,.60], wall:'#8c8a80', props:['#7a6a55','#5d6670','#8a5a3a'], tree:'#3e6b3a', night:false },
  { name:'Crépuscule',   ground:['#6a5a4a','#5f5043'], fog:'#d49a6a', sun:[1.0,.70,.45], amb:[.50,.42,.40], wall:'#7a6a60', props:['#6a5545','#55505a','#7a4a30'], tree:'#4a5a2e', night:false },
  { name:'Nuit',         ground:['#2d3a33','#27332d'], fog:'#0f1626', sun:[.35,.42,.70], amb:[.24,.28,.40], wall:'#3a4048', props:['#3a3a44','#2f3a48','#46352c'], tree:'#1f3a2c', night:true },
  { name:'Zone toxique', ground:['#566b34','#4f6330'], fog:'#8aa84a', sun:[.80,.95,.50], amb:[.45,.55,.35], wall:'#5f6a50', props:['#5a5a3a','#4a5a50','#6a5a30'], tree:'#6a7a2a', night:false }
];

// ---- MISSIONS --------------------------------------------------------
// type: 'kill' (éliminer N zombies), 'survive' (tenir N secondes), 'boss' (vaincre le boss)
// maxAlive = zombies simultanés max, int = secondes entre deux apparitions
const MISSIONS = [
  { name:'Premier contact',   type:'kill',    target:10, maxAlive:4,  int:3.2, w:{walker:1},                    theme:0, reward:120 },
  { name:'Rue déserte',       type:'kill',    target:16, maxAlive:6,  int:2.8, w:{walker:5,runner:2},           theme:0, reward:160 },
  { name:'Tenir bon',         type:'survive', time:60,   maxAlive:7,  int:2.6, w:{walker:5,runner:3},           theme:1, reward:200 },
  { name:'Crépuscule rouge',  type:'kill',    target:25, maxAlive:8,  int:2.4, w:{walker:5,runner:3,brute:1},   theme:1, reward:240 },
  { name:'Nuit blanche',      type:'kill',    target:30, maxAlive:9,  int:2.2, w:{walker:5,runner:4,brute:1},   theme:2, reward:300 },
  { name:'Évacuation',        type:'survive', time:90,   maxAlive:10, int:2.1, w:{walker:4,runner:4,brute:2},   theme:2, reward:360 },
  { name:'Zone toxique',      type:'kill',    target:40, maxAlive:11, int:1.9, w:{walker:4,runner:4,brute:2},   theme:3, reward:420 },
  { name:'La horde',          type:'kill',    target:60, maxAlive:13, int:1.6, w:{walker:5,runner:4,brute:2},   theme:3, reward:520 },
  { name:'Le Colosse',        type:'boss',    bossMul:1.0, maxAlive:7, int:3.5, w:{walker:5,runner:3,brute:1}, theme:1, reward:650 },
  { name:'Dernière nuit',     type:'boss',    bossMul:1.7, maxAlive:9, int:2.8, w:{walker:4,runner:4,brute:2}, theme:2, reward:900 }
];

// ---- AMÉLIORATIONS ---------------------------------------------------
const UPG = {
  dmg:  { name:'Dégâts',           desc:'+10 % de dégâts par niveau',        max:5, cost:l=>500+l*400 },
  hp:   { name:'Santé maximale',   desc:'+20 points de vie par niveau',      max:5, cost:l=>400+l*350 },
  ammo: { name:'Munitions',        desc:'+20 % de munitions de départ',      max:5, cost:l=>350+l*300 }
};

// ---- RANG (progression) ----------------------------------------------
function rankOf(xp){
  let lv = 1, need = 200;
  while (xp >= need) { xp -= need; lv++; need = Math.round(need * 1.25); }
  return { lv: lv, cur: xp, need: need };
}

function missionDesc(m){
  if (m.type === 'kill')    return 'Éliminer ' + m.target + ' zombies';
  if (m.type === 'survive') return 'Survivre ' + m.time + ' secondes';
  return 'Vaincre le boss';
}
