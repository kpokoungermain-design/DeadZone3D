'use strict';
/* =====================================================================
   GAME.JS  -  Le jeu : monde, zombies, armes, missions, commandes tactiles
   ===================================================================== */
const Game = (() => {

const ARENA = 42, EYE = 1.6, FOV = 1.2, Z0 = [0, 0, 0];
let canvas, W = 2, H = 2;
let colliders = [], world = null, zs = [], parts = [], picks = [], tracers = [];
let P = null, MS = null, mIdx = 0, S = null, theme = THEMES[0], owned = [], menuIdx = 0;
let state = 'boot', last = 0, menuT = 0, kick = 0, muzzle = 0, shake = 0, hitT = 0, hitHead = false, dmgT = 0, errShown = false;
const inp = { mx: 0, my: 0, fire: false, reload: false, keys: {} };
const clamp = (v, a, b) => v < a ? a : (v > b ? b : v);

function mkrng(a){                                   // générateur aléatoire reproductible
  return function(){
    let t = a += 0x6D2B79F5;
    t = Math.imul(t ^ t >>> 15, t | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}

function resize(){
  if (!canvas) return;
  const q = [.55, .8, 1][clamp(Save.data.set.q | 0, 0, 2)], dpr = Math.min(window.devicePixelRatio || 1, 2);
  W = Math.max(2, Math.round(window.innerWidth * q * dpr));
  H = Math.max(2, Math.round(window.innerHeight * q * dpr));
  canvas.width = W; canvas.height = H;
}

// ====================== MONDE (sol, murs, décors) =======================
function buildWorld(idx){
  const m = MISSIONS[idx];
  theme = THEMES[m.theme]; R.setTheme(theme);
  if (world && R.gl) R.gl.deleteBuffer(world.buf);
  const rng = mkrng(4242 + idx * 131), b = new Batch();
  colliders = [];
  const gc = theme.ground.map(C), wc = C(theme.wall), pc = theme.props.map(C), tc = C(theme.tree);
  const shade = (c, k) => [c[0] * k, c[1] * k, c[2] * k];
  const addC = (x0, x1, z0, z1, y1) => colliders.push({ x0: x0, x1: x1, z0: z0, z1: z1, y0: 0, y1: y1 });

  // sol + route
  for (let x = -ARENA - 30; x < ARENA + 30; x += 6)
    for (let z = -ARENA - 30; z < ARENA + 30; z += 6)
      b.quad(x, z, 6, 0, shade(gc[(rng() * 2) | 0], .88 + rng() * .24));
  b.box(0, .03, 0, 2 * ARENA + 6, .06, 9, [.22, .22, .24]);
  for (let x = -ARENA; x < ARENA; x += 7) b.box(x, .07, 0, 3, .03, .25, [.85, .8, .45]);

  // murs d'enceinte
  const wall = (cx, cz, sx, sz) => { b.box(cx, 2.5, cz, sx, 5, sz, wc); addC(cx - sx / 2, cx + sx / 2, cz - sz / 2, cz + sz / 2, 5); };
  wall(0, -ARENA - 1, 2 * ARENA + 4, 2); wall(0, ARENA + 1, 2 * ARENA + 4, 2);
  wall(-ARENA - 1, 0, 2, 2 * ARENA); wall(ARENA + 1, 0, 2, 2 * ARENA);
  for (let i = 0; i < 36; i++) {
    const s = (rng() * 4) | 0, p = (rng() * 2 - 1) * ARENA, h = 1 + rng() * 2.5, w = 1.5 + rng() * 2.5;
    const x = s < 2 ? p : (s === 2 ? -ARENA - 1 : ARENA + 1), z = s < 2 ? (s === 0 ? -ARENA - 1 : ARENA + 1) : p;
    b.box(x, 5 + h / 2, z, w, h, w, shade(wc, .8 + rng() * .4));
  }

  // immeubles dans le lointain
  for (let i = 0; i < 22; i++) {
    const ang = i / 22 * Math.PI * 2 + rng() * .25, dist = ARENA + 12 + rng() * 14;
    const bx = Math.cos(ang) * dist, bz = Math.sin(ang) * dist;
    const sx = 10 + rng() * 10, sz = 10 + rng() * 10, h = 12 + rng() * 26, k = .7 + rng() * .5;
    b.box(bx, h / 2, bz, sx, h, sz, shade(wc, k));
    const lit = theme.night ? .35 : .12;
    if (Math.abs(bx) > Math.abs(bz)) {
      const sg = bx > 0 ? 1 : -1, px = bx - sg * (sx / 2 + .04);
      for (let z = bz - sz / 2 + 1.6; z < bz + sz / 2 - 1; z += 3)
        for (let y = 3; y < h - 1.5; y += 3.4) b.box(px, y, z, .1, 1.5, 1.3, rng() < lit ? [.95, .8, .4] : [.14, .17, .22]);
    } else {
      const sg = bz > 0 ? 1 : -1, pz = bz - sg * (sz / 2 + .04);
      for (let x = bx - sx / 2 + 1.6; x < bx + sx / 2 - 1; x += 3)
        for (let y = 3; y < h - 1.5; y += 3.4) b.box(x, y, pz, 1.3, 1.5, .1, rng() < lit ? [.95, .8, .4] : [.14, .17, .22]);
    }
  }

  // accessoires : caisses, barrières, voitures, arbres, barils, lampadaires
  const props = [];
  const free = (x, z, r) => {
    if (Math.hypot(x, z) < 7) return false;
    for (const p of props) if (Math.hypot(x - p.x, z - p.z) < p.r + r + 1.4) return false;
    return true;
  };
  const want = 22 + idx * 2;
  for (let tries = 0, placed = 0; placed < want && tries < 700; tries++) {
    const x = (rng() * 2 - 1) * (ARENA - 4), z = (rng() * 2 - 1) * (ARENA - 4), k = rng();
    if (Math.abs(z) < 5 && !(k >= .45 && k < .62)) continue;          // la route reste dégagée (sauf voitures)
    if (k < .28) {                                                    // caisses
      const s = 1.4 + rng() * .9; if (!free(x, z, s)) continue;
      const col = shade(pc[(rng() * pc.length) | 0], .9 + rng() * .2);
      b.box(x, s / 2, z, s, s, s, col);
      let top = s;
      if (rng() < .5) { const s2 = s * .7; b.box(x + .1, s + s2 / 2, z, s2, s2, s2, shade(col, 1.1), rng()); top = s + s2; }
      addC(x - s / 2, x + s / 2, z - s / 2, z + s / 2, top);
      props.push({ x: x, z: z, r: s });
    } else if (k < .45) {                                             // barrières de béton
      if (!free(x, z, 2.4)) continue;
      const ver = rng() < .5, lx = ver ? .9 : 4.2, lz = ver ? 4.2 : .9;
      b.box(x, .6, z, lx, 1.2, lz, [.55, .55, .56]);
      b.box(x, 1.25, z, ver ? .5 : 3.8, .12, ver ? 3.8 : .5, [.9, .72, .15]);
      addC(x - lx / 2, x + lx / 2, z - lz / 2, z + lz / 2, 1.3);
      props.push({ x: x, z: z, r: 2.4 });
    } else if (k < .62) {                                             // voitures
      if (!free(x, z, 2.8)) continue;
      const ver = rng() < .5, lx = ver ? 2 : 4.4, lz = ver ? 4.4 : 2;
      const col = C(['#7a2f2f', '#2f4f7a', '#7a7a7a', '#6b6b2f', '#3a3a3e'][(rng() * 5) | 0]);
      b.box(x, .75, z, lx, .9, lz, col);
      b.box(x, 1.55, z, ver ? 1.8 : 2.2, .8, ver ? 2.2 : 1.8, shade(col, .8));
      b.box(x, 1.55, z, ver ? 1.85 : 2.25, .5, ver ? 2.25 : 1.85, [.1, .12, .15]);
      const wl = ver ? [.3, .8, .8] : [.8, .8, .3];
      for (const a of [-1, 1]) for (const c of [-1, 1]) {
        const wx = ver ? x + a * (lx / 2) : x + c * 1.4, wz = ver ? z + c * 1.4 : z + a * (lz / 2);
        b.box(wx, .4, wz, wl[0], wl[1], wl[2], [.07, .07, .08]);
      }
      addC(x - lx / 2, x + lx / 2, z - lz / 2, z + lz / 2, 1.7);
      props.push({ x: x, z: z, r: 2.8 });
    } else if (k < .82) {                                             // arbres
      if (!free(x, z, 1.6)) continue;
      b.box(x, 1.6, z, .5, 3.2, .5, [.3, .2, .12]);
      b.pyramid(x, 2.6, z, 3.4, 3.2, shade(tc, .85 + rng() * .3));
      b.pyramid(x, 4.6, z, 2.5, 2.6, shade(tc, .95 + rng() * .3));
      addC(x - .5, x + .5, z - .5, z + .5, 3.2);
      props.push({ x: x, z: z, r: 1.6 });
    } else if (k < .92) {                                             // barils
      if (!free(x, z, 1.4)) continue;
      const c1 = rng() < .5 ? [.6, .15, .12] : [.3, .36, .2];
      b.box(x - .5, .55, z - .3, .8, 1.1, .8, c1); b.box(x + .45, .55, z + .1, .8, 1.1, .8, shade(c1, .85)); b.box(x, .55, z + .6, .8, 1.1, .8, c1);
      addC(x - .9, x + .9, z - .7, z + 1, 1.1);
      props.push({ x: x, z: z, r: 1.4 });
    } else {                                                          // lampadaires
      if (!free(x, z, .7)) continue;
      b.box(x, 2.6, z, .2, 5.2, .2, [.25, .26, .28]);
      b.box(x + .35, 5.2, z, .9, .18, .35, [.2, .2, .22]);
      b.box(x + .5, 5.08, z, .5, .06, .25, theme.night ? [1, .9, .55] : [.7, .7, .6]);
      addC(x - .25, x + .25, z - .25, z + .25, 5.2);
      props.push({ x: x, z: z, r: .7 });
    }
    placed++;
  }
  // herbe et débris au sol (décor seulement)
  for (let i = 0; i < 110; i++) {
    const x = (rng() * 2 - 1) * ARENA, z = (rng() * 2 - 1) * ARENA;
    if (Math.hypot(x, z) < 3) continue;
    if (rng() < .6) b.pyramid(x, 0, z, .5, .45 + rng() * .3, shade(tc, .8 + rng() * .5));
    else b.box(x, .08, z, .4 + rng() * .6, .16, .4 + rng() * .6, shade(pc[(rng() * pc.length) | 0], .6), rng() * 3);
  }
  world = b.upload(R.gl);
}

// ====================== ZOMBIES ========================================
const SHIRTS = ['#5b4a3a', '#3a4f5b', '#5b3a3a', '#4a5b3a', '#6b6b6b', '#2f3a5b'];
function mkZ(type, x, z, hpMul){
  const T = ZTYPES[type], sc = T.scale * (.94 + Math.random() * .12);
  return { type: type, T: T, x: x, z: z, yaw: Math.random() * 6, sc: sc, hp: T.hp * hpMul, max: T.hp * hpMul,
    dead: false, dieT: 0, flash: 0, walk: Math.random() * 6, atk: .5, swing: 0, side: Math.random() < .5 ? -1 : 1, stuck: 0,
    shirt: C(T.shirt || SHIRTS[(Math.random() * SHIRTS.length) | 0]), skin: C(T.skin), pants: C(T.pants),
    idle: false, spd: T.speed * (.9 + Math.random() * .2) };
}
function pickType(){
  const w = MS.w; let tot = 0;
  for (const k in w) tot += w[k];
  let r = Math.random() * tot;
  for (const k in w) { r -= w[k]; if (r <= 0) return k; }
  return 'walker';
}
function spawnZ(type){
  const hpMul = 1 + mIdx * .05;
  for (let i = 0; i < 14; i++) {
    const a = Math.random() * 6.283, d = 24 + Math.random() * 12;
    const x = clamp(P.x + Math.cos(a) * d, -ARENA + 3, ARENA - 3), z = clamp(P.z + Math.sin(a) * d, -ARENA + 3, ARENA - 3);
    if (Math.hypot(x - P.x, z - P.z) < 15) continue;
    const tmp = { x: x, z: z }; pushOut(tmp, 1.2);
    if (Math.hypot(tmp.x - x, tmp.z - z) > .01) continue;
    const mul = type === 'boss' ? (MS.bossMul || 1) : hpMul;
    const zz = mkZ(type, x, z, mul);
    zs.push(zz); S.spawned++;
    return zz;
  }
  return null;
}

// ====================== COLLISIONS & RAYONS ============================
function pushOut(o, r){
  for (const c of colliders) {
    const cx = clamp(o.x, c.x0, c.x1), cz = clamp(o.z, c.z0, c.z1);
    const dx = o.x - cx, dz = o.z - cz, d2 = dx * dx + dz * dz;
    if (d2 < r * r) {
      if (d2 > 1e-9) { const d = Math.sqrt(d2), k = (r - d) / d; o.x += dx * k; o.z += dz * k; }
      else {
        const l = o.x - c.x0, rr = c.x1 - o.x, t = o.z - c.z0, bb = c.z1 - o.z, m = Math.min(l, rr, t, bb);
        if (m === l) o.x = c.x0 - r; else if (m === rr) o.x = c.x1 + r; else if (m === t) o.z = c.z0 - r; else o.z = c.z1 + r;
      }
    }
  }
}
function rayAABB(ox, oy, oz, dx, dy, dz, x0, y0, z0, x1, y1, z1){
  let tmin = 0, tmax = 1e9;
  const o = [ox, oy, oz], d = [dx, dy, dz], lo = [x0, y0, z0], hi = [x1, y1, z1];
  for (let i = 0; i < 3; i++) {
    if (Math.abs(d[i]) < 1e-9) { if (o[i] < lo[i] || o[i] > hi[i]) return -1; }
    else {
      let t1 = (lo[i] - o[i]) / d[i], t2 = (hi[i] - o[i]) / d[i];
      if (t1 > t2) { const t = t1; t1 = t2; t2 = t; }
      if (t1 > tmin) tmin = t1;
      if (t2 < tmax) tmax = t2;
      if (tmin > tmax) return -1;
    }
  }
  return tmin;
}
function raySphere(ox, oy, oz, dx, dy, dz, cx, cy, cz, r){
  const lx = cx - ox, ly = cy - oy, lz = cz - oz, tca = lx * dx + ly * dy + lz * dz;
  if (tca < 0) return -1;
  const d2 = lx * lx + ly * ly + lz * lz - tca * tca;
  if (d2 > r * r) return -1;
  return tca - Math.sqrt(r * r - d2);
}
function castRay(ox, oy, oz, dx, dy, dz, maxT){
  let tw = maxT;
  for (const c of colliders) {
    const t = rayAABB(ox, oy, oz, dx, dy, dz, c.x0, c.y0, c.z0, c.x1, c.y1, c.z1);
    if (t >= 0 && t < tw) tw = t;
  }
  if (dy < -1e-6) { const tg = -oy / dy; if (tg > 0 && tg < tw) tw = tg; }
  let best = null, bt = tw, head = false;
  for (const z of zs) {
    if (z.dead) continue;
    const s = z.sc;
    const tb = rayAABB(ox, oy, oz, dx, dy, dz, z.x - .38 * s, 0, z.z - .38 * s, z.x + .38 * s, 1.45 * s, z.z + .38 * s);
    const th = raySphere(ox, oy, oz, dx, dy, dz, z.x, 1.62 * s, z.z, .27 * s);
    let t = -1, hd = false;
    if (th >= 0 && (tb < 0 || th <= tb + .15)) { t = th; hd = true; }
    else if (tb >= 0) t = tb;
    if (t >= 0 && t < bt) { bt = t; best = z; head = hd; }
  }
  return { t: bt, z: best, head: head };
}

// ====================== EFFETS ==========================================
function burst(x, y, z, n, col, spd, size, emis){
  for (let i = 0; i < n && parts.length < 240; i++) {
    const a = Math.random() * 6.283, s = (.3 + Math.random()) * spd;
    parts.push({ x: x, y: y, z: z, vx: Math.cos(a) * s, vy: Math.random() * spd * .9 + 1, vz: Math.sin(a) * s,
      life: .5 + Math.random() * .5, max: 1, s: size * (.6 + Math.random() * .8), c: col, e: emis || Z0 });
  }
}
const BLOOD = [.5, .04, .04], SPARK = [1, .85, .4], DUST = [.5, .48, .42];

function updateParts(dt){
  for (const p of parts) {
    p.life -= dt; p.vy -= 14 * dt;
    p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt;
    if (p.y < .04) { p.y = .04; p.vy = 0; p.vx *= .5; p.vz *= .5; }
  }
  parts = parts.filter(p => p.life > 0);
  for (const t of tracers) t.life -= dt;
  tracers = tracers.filter(t => t.life > 0);
}

// ====================== ARMES & TIR =====================================
const fwd = () => { const cp = Math.cos(P.pitch); return [-Math.sin(P.yaw) * cp, Math.sin(P.pitch), -Math.cos(P.yaw) * cp]; };

function startReload(){
  const w = owned[P.w], a = P.ammo[w.id];
  if (P.reload > 0 || a.mag >= w.mag || a.res <= 0) return;
  P.reload = w.reload; P.zoom = false; Snd.reload();
}
function finishReload(){
  const w = owned[P.w], a = P.ammo[w.id], take = Math.min(w.mag - a.mag, a.res);
  a.mag += take; a.res -= take;
}
function setWeapon(i){
  if (!owned[i] || i === P.w) return;
  P.w = i; P.reload = 0; P.zoom = false; P.cd = .3; Snd.click();
}
function toggleZoom(){ if (state === 'play' && P.reload <= 0) P.zoom = !P.zoom; }

function tryFire(){
  const w = owned[P.w], a = P.ammo[w.id];
  if (a.mag <= 0) { if (a.res > 0) startReload(); else { Snd.empty(); P.cd = .35; } return; }
  a.mag--; P.cd = w.rate; kick = 1; muzzle = .06; Snd.shoot(w.id);
  const f = fwd(), ox = P.x, oy = EYE + P.bobY, oz = P.z;
  const rx = Math.cos(P.yaw), rz = -Math.sin(P.yaw);
  const sp = w.spread * (P.zoom ? .4 : 1), maxT = w.id === 'sniper' ? 150 : 90;
  const dmgMul = 1 + .1 * Save.data.upg.dmg;
  P.pitch = clamp(P.pitch + w.kick * .05, -1.3, 1.3);
  for (let i = 0; i < w.pellets; i++) {
    const yw = P.yaw + (Math.random() * 2 - 1) * sp, pt = P.pitch + (Math.random() * 2 - 1) * sp, cp = Math.cos(pt);
    const dx = -Math.sin(yw) * cp, dy = Math.sin(pt), dz = -Math.cos(yw) * cp;
    const hit = castRay(ox, oy, oz, dx, dy, dz, maxT);
    const ex = ox + dx * hit.t, ey = oy + dy * hit.t, ez = oz + dz * hit.t;
    tracers.push({ sx: ox + rx * .22 + f[0] * .9, sy: oy - .2 + f[1] * .9, sz: oz + rz * .22 + f[2] * .9, ex: ex, ey: ey, ez: ez, life: .05 });
    if (hit.z) {
      let d = w.dmg * dmgMul * (hit.head ? 2.2 : 1);
      if (w.pellets > 1) d *= clamp(1 - hit.t / 28, .25, 1);
      burst(ex, ey, ez, 5, BLOOD, 3, .09);
      damageZ(hit.z, d, hit.head);
    } else if (hit.t < maxT) {
      burst(ex, ey, ez, 3, SPARK, 2.5, .05, [.5, .4, .1]);
      burst(ex, ey, ez, 2, DUST, 1.5, .08);
    }
  }
}
function damageZ(z, dmg, head){
  if (z.dead) return;
  z.hp -= dmg; z.flash = .12; hitT = .18; hitHead = head; Snd.hit();
  const dx = z.x - P.x, dz = z.z - P.z, l = Math.hypot(dx, dz) || 1, kb = .05 * (160 / (z.T.hp + 100));
  z.x += dx / l * kb; z.z += dz / l * kb;
  if (z.hp <= 0) killZ(z, head, true);
}
function killZ(z, head, count){
  z.dead = true; z.dieT = 0;
  burst(z.x, 1.2 * z.sc, z.z, 14, BLOOD, 4, .12);
  Snd.zdie();
  if (!count) return;
  S.kills++; if (head) S.head++;
  const r = Math.random();
  if (z.type === 'boss') picks.push({ t: 'med', x: z.x, z: z.z, age: 0 });
  else if (r < .30) picks.push({ t: 'ammo', x: z.x, z: z.z, age: 0 });
  else if (r < .38) picks.push({ t: 'med', x: z.x, z: z.z, age: 0 });
}
function hurtPlayer(n){
  if (P.inv > 0 || P.hp <= 0) return;
  P.hp = Math.max(0, P.hp - n); P.inv = .35; dmgT = 1; shake = 1; Snd.hurt();
  if (P.hp <= 0 && state === 'play') {
    state = 'ending'; S.win = false; S.endT = 1.3; Snd.lose();
  }
}

// ====================== MISE À JOUR ====================================
function updatePlayer(dt){
  let ix = inp.mx, iy = inp.my;
  const k = inp.keys;
  if (k.w || k.z || k.arrowup) iy -= 1;
  if (k.s || k.arrowdown) iy += 1;
  if (k.a || k.q || k.arrowleft) ix -= 1;
  if (k.d || k.arrowright) ix += 1;
  const l = Math.hypot(ix, iy);
  if (l > 1) { ix /= l; iy /= l; }
  const sy = Math.sin(P.yaw), cy = Math.cos(P.yaw), sp = 5.2 * (P.zoom ? .6 : 1);
  P.moving = l > .05;
  P.x += (sy * iy + cy * ix) * sp * dt;
  P.z += (cy * iy - sy * ix) * sp * dt;
  pushOut(P, .42);
  P.x = clamp(P.x, -ARENA + .6, ARENA - .6); P.z = clamp(P.z, -ARENA + .6, ARENA - .6);
  P.bob += dt * (P.moving ? 9 : 2);
  P.bobY = Math.sin(P.bob) * (P.moving ? .045 : .006);
  P.inv -= dt; P.cd -= dt;
  if (P.reload > 0) { P.reload -= dt; if (P.reload <= 0) { P.reload = 0; finishReload(); } }
  if (inp.reload) { inp.reload = false; startReload(); }
  if ((inp.fire || inp.keys[' ']) && P.cd <= 0 && P.reload <= 0) tryFire();
  const target = FOV / (P.zoom ? owned[P.w].zoom : 1);
  P.fov += (target - P.fov) * Math.min(1, dt * 12);
}

function updateZombies(dt, active){
  for (const z of zs) {
    z.flash = Math.max(0, z.flash - dt); z.swing = Math.max(0, z.swing - dt);
    if (z.dead) { z.dieT += dt; continue; }
    if (z.idle || !active) { z.walk += dt * 1.2; continue; }
    const dx = P.x - z.x, dz = P.z - z.z, d = Math.hypot(dx, dz) || .001;
    let want = Math.atan2(dx, dz), da = want - z.yaw;
    while (da > Math.PI) da -= 6.283; while (da < -Math.PI) da += 6.283;
    z.yaw += da * Math.min(1, dt * 8);
    const reach = z.T.reach;
    if (d > reach * .85) {
      const step = z.spd * dt, px = z.x, pz = z.z;
      z.x += dx / d * step; z.z += dz / d * step;
      z.walk += dt * z.spd * 2.6;
      // évitement simple : si on est bloqué, on contourne
      if (z.stuck > .25) { z.x += -dz / d * z.side * step * 1.2; z.z += dx / d * z.side * step * 1.2; }
      pushOut(z, .45 * z.sc);
      const moved = Math.hypot(z.x - px, z.z - pz);
      if (moved < step * .35) { z.stuck += dt; if (z.stuck > 1.2) { z.side = -z.side; z.stuck = .3; } } else z.stuck = Math.max(0, z.stuck - dt);
    } else {
      z.atk -= dt;
      if (z.atk <= 0) { z.atk = 1; z.swing = .3; hurtPlayer(z.T.dmg); }
    }
  }
  // les zombies ne se superposent pas
  for (let i = 0; i < zs.length; i++) {
    const a = zs[i]; if (a.dead || a.idle) continue;
    for (let j = i + 1; j < zs.length; j++) {
      const b = zs[j]; if (b.dead) continue;
      const dx = b.x - a.x, dz = b.z - a.z, d = Math.hypot(dx, dz), m = (a.sc + b.sc) * .4;
      if (d > 0 && d < m) { const p = (m - d) / 2 / d; a.x -= dx * p; a.z -= dz * p; b.x += dx * p; b.z += dz * p; }
    }
  }
  zs = zs.filter(z => !(z.dead && z.dieT > 4));
  if (active && state === 'play') {
    for (const z of zs) if (!z.dead && Math.hypot(z.x - P.x, z.z - P.z) < 18) { Snd.groan(); break; }
  }
}

function updateSpawner(dt){
  S.time += dt; S.spawnT -= dt;
  if (MS.type === 'boss' && !S.boss && S.time > 2.5) { const b = spawnZ('boss'); if (b) { S.boss = b; UI.toast('Le Colosse approche !'); } }
  let alive = 0; for (const z of zs) if (!z.dead) alive++;
  let can = alive < MS.maxAlive;
  if (MS.type === 'kill' && S.spawned >= MS.target) can = false;
  if (can && S.spawnT <= 0) {
    spawnZ(pickType());
    const k = MS.type === 'survive' ? 1 - .45 * Math.min(1, S.time / MS.time) : 1;
    S.spawnT = MS.int * k;
  }
}

function updatePicks(dt, active){
  for (const k of picks) {
    k.age += dt;
    if (!active) continue;
    if (Math.hypot(k.x - P.x, k.z - P.z) < 1.4) {
      if (k.t === 'med') {
        if (P.hp >= P.max) continue;
        P.hp = Math.min(P.max, P.hp + 30); k.age = 99; Snd.pickup(); UI.toast('+30 PV');
      } else {
        for (const w of owned) { const a = P.ammo[w.id], cap = Math.round(w.reserve * (1 + .2 * Save.data.upg.ammo) * 1.5); a.res = Math.min(cap, a.res + Math.ceil(w.mag * 1.5)); }
        k.age = 99; Snd.pickup(); UI.toast('Munitions récupérées');
      }
    }
  }
  picks = picks.filter(k => k.age < 20);
}

function checkEnd(){
  let win = false;
  if (MS.type === 'kill' && S.kills >= MS.target) win = true;
  else if (MS.type === 'survive' && S.time >= MS.time) win = true;
  else if (MS.type === 'boss' && S.boss && S.boss.dead) win = true;
  if (win) {
    state = 'ending'; S.win = true; S.endT = 1.6;
    for (const z of zs) if (!z.dead) killZ(z, false, false);
  }
}

function update(dt){
  const play = state === 'play', ending = state === 'ending';
  if (play) updatePlayer(dt);
  P.inv = Math.max(P.inv - (play ? 0 : dt), -1);
  updateZombies(dt, play);
  if (play) updateSpawner(dt);
  updateParts(dt);
  updatePicks(dt, play);
  if (play) checkEnd();
  if (ending) {
    S.endT -= dt;
    if (S.endT <= 0) {
      state = 'result';
      if (S.win) UI.showResult(buildResult()); else UI.showDeath(!S.revived);
    }
  }
  kick = Math.max(0, kick - dt * 7); muzzle = Math.max(0, muzzle - dt);
  shake = Math.max(0, shake - dt * 5); hitT = Math.max(0, hitT - dt); dmgT = Math.max(0, dmgT - dt * 1.6);
}

function buildResult(){
  const ratio = P.hp / P.max, stars = ratio >= .7 ? 3 : (ratio >= .35 ? 2 : 1);
  const coins = MS.reward + stars * 40 + S.kills * 2, xp = S.kills * 8 + 50 + mIdx * 10;
  const d = Save.data;
  d.coins += coins; d.xp += xp; d.stars[mIdx] = Math.max(d.stars[mIdx] || 0, stars);
  Save.write(); Snd.win();
  S.result = { win: true, stars: stars, coins: coins, xp: xp, kills: S.kills, time: S.time, head: S.head, doubled: false, idx: mIdx };
  return S.result;
}

// ====================== DESSIN =========================================
function drawZ(z){
  const s = z.sc, fall = z.dead ? Math.min(1, z.dieT / .45) * -1.45 : 0, sink = z.dead && z.dieT > 3 ? (z.dieT - 3) * .8 : 0;
  const Bm = Mat.mul(Mat.T(z.x, -sink, z.z), Mat.mul(Mat.RY(z.yaw), Mat.mul(Mat.RX(fall), Mat.S(s, s, s))));
  const sw = z.dead ? 0 : Math.sin(z.walk) * .7, fl = z.flash > 0 ? [.6, .08, .08] : Z0;
  const part = (px, py, pz, rot, oy, sx, sy, sz, col, em) =>
    R.box(Mat.mul(Bm, Mat.mul(Mat.T(px, py, pz), Mat.mul(Mat.RX(rot), Mat.mul(Mat.T(0, oy, 0), Mat.S(sx, sy, sz))))), col, em || fl);
  if (!z.dead) R.box(Mat.mul(Mat.T(z.x, .02, z.z), Mat.S(.9 * s, .03, .9 * s)), [.05, .05, .05], Z0);
  part(-.15, .7, 0, sw, -.35, .24, .7, .26, z.pants);
  part(.15, .7, 0, -sw, -.35, .24, .7, .26, z.pants);
  part(0, 1.05, 0, 0, 0, .62, .72, .32, z.shirt);
  part(0, 1.6, .02, 0, 0, .36, .36, .36, z.skin);
  const arm = z.swing > 0 ? -1.75 : -1.35;
  part(-.4, 1.38, 0, arm + sw * .15, -.31, .18, .62, .18, z.skin);
  part(.4, 1.38, 0, arm - sw * .15, -.31, .18, .62, .18, z.skin);
  part(-.09, 1.63, .2, 0, 0, .07, .05, .03, [.1, 0, 0], [1, .15, .05]);
  part(.09, 1.63, .2, 0, 0, .07, .05, .03, [.1, 0, 0], [1, .15, .05]);
}
function drawPick(k){
  if (k.age > 15 && Math.floor(k.age * 6) % 2) return;
  const B = Mat.mul(Mat.T(k.x, .45 + Math.sin(k.age * 3) * .08, k.z), Mat.RY(k.age * 1.5));
  R.box(Mat.mul(Mat.T(k.x, .02, k.z), Mat.S(.7, .03, .7)), [.05, .05, .05], Z0);
  if (k.t === 'ammo') {
    R.box(Mat.mul(B, Mat.S(.55, .32, .38)), [.35, .4, .2], [.08, .08, 0]);
    R.box(Mat.mul(B, Mat.mul(Mat.T(0, .17, 0), Mat.S(.4, .04, .2))), [.9, .75, .2], [.25, .2, 0]);
  } else {
    R.box(Mat.mul(B, Mat.S(.5, .4, .5)), [.9, .9, .9], [.15, .15, .15]);
    R.box(Mat.mul(B, Mat.mul(Mat.T(0, .21, 0), Mat.S(.34, .04, .1))), [.8, .1, .1], [.5, 0, 0]);
    R.box(Mat.mul(B, Mat.mul(Mat.T(0, .21, 0), Mat.S(.1, .04, .34))), [.8, .1, .1], [.5, 0, 0]);
  }
}
function drawTracer(t){
  const dx = t.ex - t.sx, dy = t.ey - t.sy, dz = t.ez - t.sz, len = Math.hypot(dx, dy, dz);
  if (len < .2) return;
  const yaw = Math.atan2(dx, dz), el = Math.asin(clamp(dy / len, -1, 1)), th = .03 * (t.life / .05);
  R.box(Mat.mul(Mat.T((t.sx + t.ex) / 2, (t.sy + t.ey) / 2, (t.sz + t.ez) / 2), Mat.mul(Mat.RY(yaw), Mat.mul(Mat.RX(-el), Mat.S(th, th, len)))),
        [1, .9, .5], [1, .8, .4]);
}
const SKIN = [.8, .62, .5], SLEEVE = [.2, .24, .3];
function drawGun(){
  const w = owned[P.w];
  if (P.zoom && w.scope) return;
  R.beginGun(Mat.persp(1.0, W / H, .02, 10));
  const mv = P.moving ? 1 : .25, bob = Math.sin(P.bob) * .012 * mv, bobx = Math.cos(P.bob * .5) * .01 * mv;
  const rl = P.reload > 0 ? Math.sin(Math.min(1, 1 - P.reload / w.reload) * Math.PI) : 0;
  const zx = P.zoom ? -.14 : 0, zy = P.zoom ? .03 : 0;
  const G = Mat.mul(Mat.T(.2 + zx + bobx, -.2 + zy + bob - rl * .25, -.38 + kick * .07), Mat.RX(kick * .1 + rl * .6));
  for (const p of w.body) {
    if (!p[7]) p[7] = C(p[6]);
    R.box(Mat.mul(G, Mat.mul(Mat.T(p[0], p[1], p[2]), Mat.S(p[3], p[4], p[5]))), p[7], Z0);
  }
  R.box(Mat.mul(G, Mat.mul(Mat.T(0, -.07, -.01), Mat.S(.075, .1, .08))), SKIN, Z0);
  R.box(Mat.mul(G, Mat.mul(Mat.T(.02, -.12, .1), Mat.S(.09, .09, .22))), SLEEVE, Z0);
  R.box(Mat.mul(G, Mat.mul(Mat.T(-.01, -.03, -.3), Mat.S(.07, .07, .11))), SKIN, Z0);
  if (muzzle > 0) {
    const s = .1 + Math.random() * .08;
    R.box(Mat.mul(G, Mat.mul(Mat.T(0, .01, w.mz - .05), Mat.mul(Mat.RX(Math.random() * 3), Mat.S(s, s, .1)))), [1, .8, .3], [1, .75, .25]);
  }
}

function render(){
  if (!R.gl || !world) return;
  let eye, tgt, fov = FOV;
  if (state === 'menu') {
    const a = menuT * .18;
    eye = [Math.cos(a) * 13, 4.2, Math.sin(a) * 13]; tgt = [0, 1.4, 0];
  } else {
    eye = [P.x, EYE + P.bobY, P.z];
    if (shake > 0) { eye[0] += (Math.random() - .5) * shake * .06; eye[1] += (Math.random() - .5) * shake * .06; }
    const f = fwd(); tgt = [eye[0] + f[0], eye[1] + f[1], eye[2] + f[2]]; fov = P.fov;
  }
  const vp = Mat.mul(Mat.persp(fov, W / H, .1, 150), Mat.lookAt(eye, tgt));
  R.begin(vp, eye, W, H);
  R.drawStatic(world);
  for (const k of picks) drawPick(k);
  for (const z of zs) drawZ(z);
  for (const p of parts) { const s = p.s * Math.max(.15, p.life / p.max); R.box(Mat.mul(Mat.T(p.x, p.y, p.z), Mat.S(s, s, s)), p.c, p.e); }
  for (const t of tracers) drawTracer(t);
  if (state !== 'menu' && state !== 'result') drawGun();
}

// ====================== INTERFACE EN JEU ===============================
const hc = {};
const setT = (id, v) => { if (hc[id] !== v) { hc[id] = v; $(id).textContent = v; } };
const setW = (id, v) => { if (hc[id] !== v) { hc[id] = v; $(id).style.width = v; } };
const setO = (id, v) => { if (hc[id] !== v) { hc[id] = v; $(id).style.opacity = v; } };
function updateHud(){
  const w = owned[P.w], a = P.ammo[w.id];
  setW('hpFill', Math.max(0, Math.round(100 * P.hp / P.max)) + '%');
  setT('hpText', String(Math.ceil(P.hp)));
  setT('ammoText', P.reload > 0 ? 'Rechargement…' : a.mag + ' / ' + a.res);
  setT('weaponName', w.name);
  let obj;
  if (MS.type === 'kill') obj = 'Zombies : ' + Math.min(S.kills, MS.target) + ' / ' + MS.target;
  else if (MS.type === 'survive') { const r = Math.max(0, Math.ceil(MS.time - S.time)); obj = 'Survivre : ' + Math.floor(r / 60) + ':' + ('0' + (r % 60)).slice(-2); }
  else obj = S.boss ? 'Vaincre le Colosse' : 'Préparez-vous…';
  setT('objective', obj);
  const showBoss = !!(S.boss && !S.boss.dead);
  if (hc.boss !== showBoss) { hc.boss = showBoss; $('bossBar').classList.toggle('hidden', !showBoss); }
  if (showBoss) setW('bossFill', Math.max(0, Math.round(100 * S.boss.hp / S.boss.max)) + '%');
  setO('dmg', String(Math.min(1, dmgT).toFixed(2)));
  const hm = hitT > 0 ? (hitHead ? 'head' : 'on') : '';
  if (hc.hm !== hm) { hc.hm = hm; $('hitmark').className = hm; }
  const sc = P.zoom && w.scope;
  if (hc.scope !== sc) { hc.scope = sc; $('scope').classList.toggle('hidden', !sc); $('crosshair').classList.toggle('hidden', sc); }
  if (hc.zoomOn !== P.zoom) { hc.zoomOn = P.zoom; $('btnZoom').classList.toggle('active', P.zoom); }
}

// ====================== CYCLE DE VIE ===================================
function menuScene(){
  buildWorld(menuIdx);
  zs = []; parts = []; picks = []; tracers = [];
  for (let i = 0; i < 7; i++) {
    const a = i / 7 * 6.283 + .4, d = 5 + Math.random() * 5;
    const t = ['walker', 'walker', 'runner', 'brute'][i % 4];
    const z = mkZ(t, Math.cos(a) * d, Math.sin(a) * d, 1);
    z.idle = true; z.yaw = Math.atan2(-Math.cos(a), -Math.sin(a)) + (Math.random() - .5);
    zs.push(z);
  }
  P = null; state = 'menu';
}

function start(i){
  mIdx = i; MS = MISSIONS[i]; menuIdx = i;
  buildWorld(i);
  zs = []; parts = []; picks = []; tracers = [];
  owned = WEAPONS.filter(w => Save.data.owned.indexOf(w.id) >= 0);
  const up = Save.data.upg, maxhp = 100 + 20 * up.hp, ammo = {};
  for (const w of owned) ammo[w.id] = { mag: w.mag, res: Math.round(w.reserve * (1 + .2 * up.ammo)) };
  P = { x: 0, z: 0, yaw: 0, pitch: 0, hp: maxhp, max: maxhp, w: owned.length - 1, ammo: ammo, cd: .4, reload: 0, zoom: false,
        fov: FOV, bob: 0, bobY: 0, moving: false, inv: 1 };
  S = { time: 0, kills: 0, head: 0, spawned: 0, spawnT: 1.2, boss: null, endT: 0, win: false, revived: false, paid: false, result: null };
  kick = 0; muzzle = 0; shake = 0; hitT = 0; dmgT = 0;
  for (const k in hc) delete hc[k];
  inp.mx = inp.my = 0; inp.fire = false;
  state = 'play';
  UI.show('hud');
  Snd.init(); Snd.resume();
  UI.toast(MS.name + ' : ' + missionDesc(MS));
}
function toMenu(){ leave(); UI.show('sc-menu'); menuScene(); }
function leave(){
  if (S && !S.win && !S.paid && P) { S.paid = true; Save.data.coins += Math.floor(S.kills / 2); Save.write(); }
}
function retry(){ leave(); start(mIdx); }
function next(){ if (mIdx < MISSIONS.length - 1) start(mIdx + 1); }
function pause(){ if (state !== 'play') return; state = 'paused'; inp.fire = false; UI.show('sc-pause'); }
function resume(){ if (state !== 'paused') return; state = 'play'; UI.show('hud'); }
function autoPause(){ if (state === 'play') pause(); }
function revive(){
  if (!S || S.revived) return;
  S.revived = true; P.hp = P.max * .6; P.inv = 3;
  for (const z of zs) if (!z.dead && Math.hypot(z.x - P.x, z.z - P.z) < 14) killZ(z, false, true);
  state = 'play'; UI.show('hud');
}
function reviveWithAd(){ Ads.rewarded(revive); }
function doubleReward(){
  if (!S || !S.result || S.result.doubled) return;
  Ads.rewarded(() => {
    S.result.doubled = true; Save.data.coins += S.result.coins; Save.write();
    Snd.pickup(); UI.showResult(S.result);
  });
}

// ====================== COMMANDES (tactile + clavier) ==================
function bindInput(){
  const joyZone = $('joyZone'), look = $('lookZone'), base = $('joyBase'), knob = $('joyKnob');
  let jid = null, jx = 0, jy = 0, lid = null, lx = 0, ly = 0, fid = null, fx = 0, fy = 0;
  const RAD = 48, gesture = () => { Snd.init(); Snd.resume(); };
  const find = (list, id) => { for (const t of list) if (t.identifier === id) return t; return null; };
  const lookBy = (dx, dy) => {
    if (!P || state !== 'play') return;
    const w = owned[P.w], z = P.zoom ? (w.scope ? .28 : .6) : 1, k = .0045 * Save.data.set.sens * z;
    P.yaw -= dx * k; P.pitch = clamp(P.pitch - dy * k, -1.3, 1.3);
  };
  const bindLook = (el, getId, setId, getXY, setXY, onStart, onEnd) => {
    el.addEventListener('touchstart', e => {
      e.preventDefault(); gesture(); e.stopPropagation();
      if (getId() !== null) return;
      const t = e.changedTouches[0]; setId(t.identifier); setXY(t.clientX, t.clientY); onStart && onStart();
    }, { passive: false });
    el.addEventListener('touchmove', e => {
      e.preventDefault();
      const t = find(e.changedTouches, getId()); if (!t) return;
      const p = getXY(); lookBy(t.clientX - p[0], t.clientY - p[1]); setXY(t.clientX, t.clientY);
    }, { passive: false });
    const end = e => { if (find(e.changedTouches, getId())) { setId(null); onEnd && onEnd(); } };
    el.addEventListener('touchend', end); el.addEventListener('touchcancel', end);
  };
  bindLook(look, () => lid, v => { lid = v; }, () => [lx, ly], (x, y) => { lx = x; ly = y; });
  bindLook($('btnFire'), () => fid, v => { fid = v; }, () => [fx, fy], (x, y) => { fx = x; fy = y; },
           () => { inp.fire = true; $('btnFire').classList.add('active'); },
           () => { inp.fire = false; $('btnFire').classList.remove('active'); });

  joyZone.addEventListener('touchstart', e => {
    e.preventDefault(); gesture();
    if (jid !== null) return;
    const t = e.changedTouches[0]; jid = t.identifier; jx = t.clientX; jy = t.clientY;
    base.style.left = jx + 'px'; base.style.top = jy + 'px'; knob.style.left = jx + 'px'; knob.style.top = jy + 'px';
    base.classList.add('on'); knob.classList.add('on');
  }, { passive: false });
  joyZone.addEventListener('touchmove', e => {
    e.preventDefault();
    const t = find(e.changedTouches, jid); if (!t) return;
    let dx = t.clientX - jx, dy = t.clientY - jy; const l = Math.hypot(dx, dy);
    if (l > RAD) { dx = dx / l * RAD; dy = dy / l * RAD; }
    knob.style.left = (jx + dx) + 'px'; knob.style.top = (jy + dy) + 'px';
    let mx = dx / RAD, my = dy / RAD;
    if (Math.hypot(mx, my) < .15) { mx = 0; my = 0; }
    inp.mx = mx; inp.my = my;
  }, { passive: false });
  const jend = e => {
    if (find(e.changedTouches, jid)) { jid = null; inp.mx = 0; inp.my = 0; base.classList.remove('on'); knob.classList.remove('on'); }
  };
  joyZone.addEventListener('touchend', jend); joyZone.addEventListener('touchcancel', jend);

  const press = (id, fn) => {
    const el = $(id);
    el.addEventListener('touchstart', e => { e.preventDefault(); e.stopPropagation(); gesture(); fn(); }, { passive: false });
    el.addEventListener('mousedown', e => { e.preventDefault(); e.stopPropagation(); fn(); });
  };
  press('btnReload', () => { if (state === 'play') inp.reload = true; });
  press('btnSwitch', () => { if (state === 'play' && P) setWeapon((P.w + 1) % owned.length); });
  press('btnZoom', toggleZoom);
  press('btnPause', pause);

  // clavier + souris (pour tester sur ordinateur)
  window.addEventListener('keydown', e => {
    const k = e.key.toLowerCase(); inp.keys[k] = true;
    if (state !== 'play') return;
    if (k === 'r') inp.reload = true;
    if (k === 'x') setWeapon((P.w + 1) % owned.length);
    if (k >= '1' && k <= '5' && owned[+k - 1]) setWeapon(+k - 1);
    if (k === 'escape') pause();
    if (k === ' ') e.preventDefault();
  });
  window.addEventListener('keyup', e => { inp.keys[e.key.toLowerCase()] = false; });
  $('hud').addEventListener('click', () => {
    if (state === 'play' && !('ontouchstart' in window) && canvas.requestPointerLock) canvas.requestPointerLock();
  });
  document.addEventListener('mousemove', e => { if (document.pointerLockElement === canvas) lookBy(e.movementX, e.movementY); });
  document.addEventListener('mousedown', e => {
    if (document.pointerLockElement !== canvas) return;
    if (e.button === 0) inp.fire = true; else if (e.button === 2) toggleZoom();
  });
  document.addEventListener('mouseup', e => { if (e.button === 0 && document.pointerLockElement === canvas) inp.fire = false; });
  document.addEventListener('contextmenu', e => e.preventDefault());
  document.addEventListener('visibilitychange', () => { if (document.hidden) autoPause(); });
  window.addEventListener('blur', autoPause);
  window.addEventListener('resize', resize);
}

// ====================== DÉMARRAGE ======================================
function step(dt){
  if (state === 'boot') return;
  if (state === 'menu') { menuT += dt; updateZombies(dt, false); updateParts(dt); }
  else if (state === 'play' || state === 'ending') { update(dt); updateHud(); }
  else if (state === 'result') { updateParts(dt); updateZombies(dt, false); kick = 0; }
  render();
}
function frame(now){
  requestAnimationFrame(frame);
  const dt = Math.min(.05, Math.max(0, (now - last) / 1000)); last = now;
  try { step(dt); }
  catch (e) { if (!errShown) { errShown = true; UI.toast('Erreur : ' + e.message); } if (window.console) console.error(e); }
}

function init(){
  Save.load(); Snd.on = !!Save.data.set.snd;
  canvas = $('gl');
  try {
    if (!R.init(canvas)) throw new Error('WebGL indisponible');
  } catch (e) {
    $('sc-menu').innerHTML = '<h1>Dead Zone</h1><p>Ce téléphone ne supporte pas la 3D (WebGL).<br>' + e.message + '</p>';
    return;
  }
  canvas.addEventListener('webglcontextlost', e => e.preventDefault());
  canvas.addEventListener('webglcontextrestored', () => location.reload());
  resize(); UI.init(); bindInput();
  UI.show('sc-menu'); menuScene();
  requestAnimationFrame(frame);
}

return { init: init, start: start, retry: retry, next: next, toMenu: toMenu, leave: leave, pause: pause, resume: resume,
         autoPause: autoPause, reviveWithAd: reviveWithAd, doubleReward: doubleReward, resize: resize, step: step,
         _dbg: () => ({ state: state, S: S, P: P, zs: zs, picks: picks, owned: owned, inp: inp, MS: MS }) };
})();
