package com.deadzone.game;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;

import androidx.annotation.NonNull;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.gms.ads.OnUserEarnedRewardListener;

/**
 * Écran unique de l'application : il affiche le jeu (une page web locale en 3D WebGL)
 * et gère les publicités AdMob (bannière + vidéo récompensée) et la sauvegarde.
 */
public class MainActivity extends Activity {

    private WebView webView;
    private AdView bannerView;
    private FrameLayout bannerBox;
    private RewardedAd rewardedAd;
    private boolean rewardedLoading = false;
    private boolean rewardEarned = false;
    private boolean adsReady = false;
    private boolean bannerWanted = false;
    private boolean bannerLoaded = false;
    private OnBackInvokedCallback backCallback;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        // Disposition verticale : le jeu en haut, la bannière en bas
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        root.addView(webView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        bannerBox = new FrameLayout(this);
        bannerBox.setVisibility(View.GONE);
        root.addView(bannerBox, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(root);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);                  // lecture des fichiers du jeu dans /assets
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setLongClickable(false);
        webView.setOnLongClickListener(v -> true);
        webView.addJavascriptInterface(new Bridge(), "Android");
        webView.loadUrl("file:///android_asset/www/index.html");

        // Initialisation du SDK publicitaire (en arrière-plan, comme le recommande Google)
        new Thread(() -> {
            MobileAds.initialize(this, status -> {
                adsReady = true;
                runOnUiThread(() -> {
                    loadRewarded();
                    if (bannerWanted) showBanner(true);
                });
            });
        }).start();

        setupBack();
    }

    // ---------- Bouton retour ----------
    private void setupBack() {
        if (Build.VERSION.SDK_INT >= 33) {
            backCallback = this::handleBack;
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT, backCallback);
        }
    }

    private void handleBack() {
        webView.evaluateJavascript("(window.onNativeBack ? window.onNativeBack() : 'exit')", value -> {
            if (value == null || value.contains("exit")) finish();
        });
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {      // Android 12 et moins
        handleBack();
    }

    // ---------- Plein écran immersif ----------
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }

    @SuppressWarnings("deprecation")
    private void hideSystemBars() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    // ---------- Cycle de vie ----------
    @Override
    protected void onPause() {
        super.onPause();
        webView.evaluateJavascript("if(window.onNativePause)window.onNativePause();", null);
        webView.onPause();
        if (bannerView != null) bannerView.pause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
        if (bannerView != null) bannerView.resume();
        hideSystemBars();
    }

    @Override
    protected void onDestroy() {
        if (Build.VERSION.SDK_INT >= 33 && backCallback != null) {
            getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(backCallback);
        }
        if (bannerView != null) bannerView.destroy();
        webView.destroy();
        super.onDestroy();
    }

    // ---------- Bannière ----------
    private void showBanner(boolean show) {
        bannerWanted = show;
        if (!adsReady) return;
        if (!show) {
            bannerBox.setVisibility(View.GONE);
            return;
        }
        if (bannerView == null) {
            bannerView = new AdView(this);
            bannerView.setAdUnitId(getString(R.string.admob_banner_id));
            bannerView.setAdSize(AdSize.BANNER);
            bannerView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                    bannerLoaded = true;
                    if (bannerWanted) bannerBox.setVisibility(View.VISIBLE);
                }

                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError error) {
                    bannerLoaded = false;
                    bannerBox.setVisibility(View.GONE);
                }
            });
            bannerBox.addView(bannerView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT, android.view.Gravity.CENTER_HORIZONTAL));
            bannerView.loadAd(new AdRequest.Builder().build());
        } else if (bannerLoaded) {
            bannerBox.setVisibility(View.VISIBLE);
        }
    }

    // ---------- Vidéo récompensée ----------
    private void loadRewarded() {
        if (!adsReady || rewardedLoading || rewardedAd != null) return;
        rewardedLoading = true;
        RewardedAd.load(this, getString(R.string.admob_rewarded_id), new AdRequest.Builder().build(),
                new RewardedAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull RewardedAd ad) {
                        rewardedAd = ad;
                        rewardedLoading = false;
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError error) {
                        rewardedAd = null;
                        rewardedLoading = false;
                    }
                });
    }

    private void showRewarded() {
        final RewardedAd ad = rewardedAd;
        if (ad == null) {
            sendReward(false, "unavailable");
            loadRewarded();
            return;
        }
        rewardEarned = false;
        ad.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override
            public void onAdDismissedFullScreenContent() {
                rewardedAd = null;
                // La récompense n'est donnée que si la vidéo a été regardée jusqu'au bout
                sendReward(rewardEarned, rewardEarned ? "ok" : "closed");
                loadRewarded();
            }

            @Override
            public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                rewardedAd = null;
                sendReward(false, "unavailable");
                loadRewarded();
            }
        });
        ad.show(this, new OnUserEarnedRewardListener() {
            @Override
            public void onUserEarnedReward(@NonNull RewardItem rewardItem) {
                rewardEarned = true;
            }
        });
    }

    private void sendReward(boolean ok, String reason) {
        webView.evaluateJavascript("if(window.onRewardResult)window.onRewardResult(" + ok + ",'" + reason + "');", null);
    }

    // ---------- Pont JavaScript <-> Android ----------
    public class Bridge {
        private SharedPreferences prefs() {
            return getSharedPreferences("deadzone", Context.MODE_PRIVATE);
        }

        @JavascriptInterface
        public String load() {
            return prefs().getString("save", "");
        }

        @JavascriptInterface
        public void save(String json) {
            if (json != null && json.length() < 20000) prefs().edit().putString("save", json).apply();
        }

        @JavascriptInterface
        public void setBanner(boolean show) {
            runOnUiThread(() -> showBanner(show));
        }

        @JavascriptInterface
        public void showRewarded() {
            runOnUiThread(MainActivity.this::showRewarded);
        }
    }
}
