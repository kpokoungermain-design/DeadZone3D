# Les méthodes appelées depuis le JavaScript du jeu ne doivent pas être renommées.
-keepclassmembers class com.deadzone.game.MainActivity$Bridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keepattributes JavascriptInterface
