plugins {
    id("com.android.application")
}

android {
    namespace = "com.deadzone.game"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.deadzone.game"   // identifiant unique sur Google Play : à changer AVANT la publication
        minSdk = 24
        targetSdk = 36                         // Google Play exige 36 depuis le 31 août 2026
        versionCode = 1                        // à augmenter de 1 à chaque nouvelle version publiée
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("com.google.android.gms:play-services-ads:25.5.0")
}
