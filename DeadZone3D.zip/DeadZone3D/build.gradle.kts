// Fichier racine : il déclare seulement la version du plugin Android.
plugins {
    id("com.android.application") version "9.4.0" apply false
}
